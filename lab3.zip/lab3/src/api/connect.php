<?php
$host = 'localhost';
$user = 'f0547999_root';
$password = '123';
$database = 'f0547999_db';
$queryTab0 = 'news';
$queryTab1 = 'comments';
?>